/* -*- Mode: js; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global WapPushManager */

'use strict';

navigator.mozL10n.once(WapPushManager.init.bind(WapPushManager));
