define(['require','exports','module','debug','lib/sounds'],function(require, exports, module) {


/**
 * Dependencies
 */

var debug = require('debug')('controller:sounds');
var Sounds = require('lib/sounds');

/**
 * Exports
 */

module.exports = function(app) { return new SoundsController(app); };
module.exports.SoundsController = SoundsController;

/**
 * Initialize a new `SoundsController`
 *
 * @param {App} app [description]
 */
function SoundsController(app) {
  debug('initializing');
  var list = app.settings.sounds.get('list');
  this.sounds = new Sounds(list);
  this.app = app;
  this.bindEvents();
  debug('initialized');
}

SoundsController.prototype.bindEvents = function() {
  this.app.on('change:recording', this.onRecordingChange.bind(this));
  this.app.on('camera:shutter', this.sounds.player('shutter'));
};

/**
 * Plays the start/end recording sound.
 *
 * @private
 */
SoundsController.prototype.onRecordingChange = function(recording) {
  if (recording) { this.sounds.play('recordingStart'); }
  else { this.sounds.play('recordingEnd'); }
};

});
