'use strict';

/* exported MockDatastoreMigration */

var MockDatastoreMigration = function() {
  this.start = function() {};
};
