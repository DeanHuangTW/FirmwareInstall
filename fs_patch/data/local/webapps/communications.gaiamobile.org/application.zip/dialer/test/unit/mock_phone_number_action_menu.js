/* exported MockPhoneNumberActionMenu */

'use strict';

var MockPhoneNumberActionMenu = {
  show: function() {}
};
