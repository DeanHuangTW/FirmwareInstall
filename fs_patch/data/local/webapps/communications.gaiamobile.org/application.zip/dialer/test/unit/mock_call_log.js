'use strict';

/* exported MockCallLog */

var MockCallLog = {
  appendGroup: function(group) {
  }
};

