'use strict';

/* exported MockVoicemail */

var MockVoicemail = {
  check: function(number, cb) {
    cb(false);
  }
};
